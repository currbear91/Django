from django.shortcuts import render,redirect
from .models import User
from django.contrib import messages


# Create your views here.
def index(request):

	return render(request, "loginRegAppTemplates/index.html")

# Create your views here.

def index(request):


	return render(request, 'loginRegAppTemplates/index.html')

def process(request):
	
	if User.userManager.validRegister(request.POST):
		return redirect('/success')
	else:
		messages.error(request, 'This is an invalid email.')
		error = False
		return redirect('/')


def success(request):

	context = {

		"emails" : User.userManager.all()[::-1]
		# "names" : Email.e,
	}


	return render(request, 'loginRegAppTemplates/success.html', context)

	