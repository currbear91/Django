from __future__ import unicode_literals

from django.db import models
import re
import bcrypt

EMAIL_REGEX =  re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

# Create your models here.

class UserManager(models.Manager):

	# def login(self, email, password):
	errors=[]

	def validRegister(self, userInfo):
		#userInfo is a dictionary of stuff from request.POST['']
		password = userInfo['password']
		# hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())


		if not EMAIL_REGEX.match(userInfo['email']):
			print "Did not match"
			return False
		else:
			print "Match"

		if len(userInfo['first_name']) < 1:
			flash("First name cannot be empty!", "error")
			error = False
		if len(userInfo['last_name']) < 1:
			flash("Last Name cannot be empty!", "error")
			error = False
		if len(userInfo['email']) < 1:
			flash("Email cannot be empty", "error")
			error = False
		if len(userInfo['password']) < 1:
			flash("Password cannot be empty!" , "error")
			error = False
		if len(userInfo['confirm']) < 1:
			flash("Password cannot be empty!", "error")
			error = False
		if userInfo['password'] != userInfo['confirm']:
			flash("Passwords must match","error")
			error = False
		if error == True:
			User.userManager.create(email = userInfo['email'], first_name = userInfo['first_name'], last_name = userInfo ['last_name'], password = userInfo['password'])
 
	


class User(models.Model):
	first_name = models.CharField(max_length = 255)
	last_name = models.CharField(max_length = 255)
	email = models.EmailField()
	password = models.CharField(max_length = 255)
	created_at = models.DateField(auto_now_add = True)
	updated_at = models.DateField(auto_now = True)
	userManager = UserManager()

